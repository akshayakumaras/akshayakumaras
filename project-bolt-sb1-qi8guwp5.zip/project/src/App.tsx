import React, { useState } from 'react';
import { Recycle, MapPin, CreditCard, ChevronRight, ChevronLeft, History, Home, Building2, Leaf, Globe2, Target, AlertTriangle } from 'lucide-react';
import EWasteInfo from './components/WorldMap';
import OrderHistory from './components/OrderHistory';

interface Address {
  country: string;
  state: string;
  city: string;
  street: string;
  zipCode: string;
}

interface EWasteItem {
  type: string;
  quantity: number;
}

interface Order {
  id: string;
  date: string;
  address: Address;
  items: EWasteItem[];
  status: 'pending' | 'collected' | 'processed';
}

type ViewType = 'info' | 'residential' | 'commercial' | 'sustainability' | 'collection' | 'history';

function App() {
  const [currentView, setCurrentView] = useState<ViewType>('info');
  const [step, setStep] = useState(1);
  const [address, setAddress] = useState<Address>({
    country: '',
    state: '',
    city: '',
    street: '',
    zipCode: '',
  });
  const [items, setItems] = useState<EWasteItem[]>([
    { type: 'Computers', quantity: 0 },
    { type: 'Mobile Phones', quantity: 0 },
    { type: 'Batteries', quantity: 0 },
    { type: 'Monitors', quantity: 0 },
  ]);

  const [orderHistory, setOrderHistory] = useState<Order[]>([
    {
      id: '1',
      date: '2024-03-15',
      address: {
        country: 'United States',
        state: 'California',
        city: 'San Francisco',
        street: '123 Tech Street',
        zipCode: '94105'
      },
      items: [
        { type: 'Computers', quantity: 2 },
        { type: 'Mobile Phones', quantity: 3 }
      ],
      status: 'collected'
    },
    {
      id: '2',
      date: '2024-03-10',
      address: {
        country: 'Canada',
        state: 'Ontario',
        city: 'Toronto',
        street: '456 Eco Avenue',
        zipCode: 'M5V 2T6'
      },
      items: [
        { type: 'Batteries', quantity: 10 },
        { type: 'Monitors', quantity: 1 }
      ],
      status: 'pending'
    }
  ]);

  const handleAddressChange = (field: keyof Address, value: string) => {
    setAddress(prev => ({ ...prev, [field]: value }));
  };

  const handleQuantityChange = (index: number, value: number) => {
    const newItems = [...items];
    newItems[index].quantity = Math.max(0, value);
    setItems(newItems);
  };

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      const newOrder: Order = {
        id: (orderHistory.length + 1).toString(),
        date: new Date().toISOString().split('T')[0],
        address: { ...address },
        items: items.filter(item => item.quantity > 0),
        status: 'pending'
      };

      setOrderHistory(prev => [newOrder, ...prev]);
      setAddress({
        country: '',
        state: '',
        city: '',
        street: '',
        zipCode: '',
      });
      setItems([
        { type: 'Computers', quantity: 0 },
        { type: 'Mobile Phones', quantity: 0 },
        { type: 'Batteries', quantity: 0 },
        { type: 'Monitors', quantity: 0 },
      ]);
      setStep(1);
      
      alert('Pickup scheduled successfully! You can track your order in the Order History.');
      setCurrentView('history');
    }
  };

  const renderResidentialContent = () => (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 to-blue-800 text-white p-8 md:p-12">
        <div className="relative z-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Residential E-Waste Collection</h1>
          <p className="text-lg md:text-xl text-blue-50 max-w-2xl">
            Safe and convenient e-waste disposal solutions for households. We make it easy to responsibly dispose of your electronic devices.
          </p>
        </div>
        <div className="absolute right-0 bottom-0 opacity-10">
          <Home size={240} />
        </div>
      </div>

      {/* Services */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-blue-50 rounded-lg p-6">
            <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
              <MapPin className="text-blue-600" size={24} />
            </div>
            <h3 className="font-bold text-gray-800 mb-2">Door-to-Door Collection</h3>
            <p className="text-gray-600">Convenient pickup service right from your doorstep.</p>
          </div>
          <div className="bg-blue-50 rounded-lg p-6">
            <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
              <Recycle className="text-blue-600" size={24} />
            </div>
            <h3 className="font-bold text-gray-800 mb-2">Responsible Recycling</h3>
            <p className="text-gray-600">Eco-friendly processing of all collected e-waste.</p>
          </div>
          <div className="bg-blue-50 rounded-lg p-6">
            <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
              <Target className="text-blue-600" size={24} />
            </div>
            <h3 className="font-bold text-gray-800 mb-2">Data Security</h3>
            <p className="text-gray-600">Secure data destruction for all storage devices.</p>
          </div>
        </div>
      </div>

      {/* Accepted Items */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">What We Accept</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            'Computers & Laptops',
            'Mobile Phones',
            'Tablets',
            'Printers',
            'TVs & Monitors',
            'Gaming Consoles',
            'Cables & Chargers',
            'Small Appliances'
          ].map(item => (
            <div key={item} className="bg-gray-50 rounded-lg p-4">
              <p className="text-center text-gray-700">{item}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderCommercialContent = () => (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-purple-600 to-purple-800 text-white p-8 md:p-12">
        <div className="relative z-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Commercial E-Waste Solutions</h1>
          <p className="text-lg md:text-xl text-purple-50 max-w-2xl">
            Comprehensive e-waste management solutions for businesses of all sizes. We help organizations dispose of their electronic waste responsibly.
          </p>
        </div>
        <div className="absolute right-0 bottom-0 opacity-10">
          <Building2 size={240} />
        </div>
      </div>

      {/* Services */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Business Services</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-purple-50 rounded-lg p-6">
            <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
              <Building2 className="text-purple-600" size={24} />
            </div>
            <h3 className="font-bold text-gray-800 mb-2">Bulk Collection</h3>
            <p className="text-gray-600">Large-scale pickup services for office clearances and upgrades.</p>
          </div>
          <div className="bg-purple-50 rounded-lg p-6">
            <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
              <Target className="text-purple-600" size={24} />
            </div>
            <h3 className="font-bold text-gray-800 mb-2">Asset Management</h3>
            <p className="text-gray-600">Detailed tracking and reporting of disposed assets.</p>
          </div>
          <div className="bg-purple-50 rounded-lg p-6">
            <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
              <AlertTriangle className="text-purple-600" size={24} />
            </div>
            <h3 className="font-bold text-gray-800 mb-2">Compliance</h3>
            <p className="text-gray-600">Full compliance with environmental regulations and data protection laws.</p>
          </div>
        </div>
      </div>

      {/* Benefits */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Business Benefits</h2>
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Operational Benefits</h3>
            <ul className="space-y-3">
              {[
                'Streamlined disposal process',
                'Reduced storage requirements',
                'Professional asset tracking',
                'Regular collection schedules',
                'Customized solutions'
              ].map(item => (
                <li key={item} className="flex items-center space-x-2 text-gray-600">
                  <div className="w-2 h-2 bg-purple-500 rounded-full" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Compliance & Security</h3>
            <ul className="space-y-3">
              {[
                'Environmental compliance',
                'Data security certificates',
                'Audit trail maintenance',
                'Regulatory documentation',
                'Secure data destruction'
              ].map(item => (
                <li key={item} className="flex items-center space-x-2 text-gray-600">
                  <div className="w-2 h-2 bg-purple-500 rounded-full" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSustainabilityContent = () => (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-green-600 to-emerald-800 text-white p-8 md:p-12">
        <div className="relative z-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Sustainability Goals</h1>
          <p className="text-lg md:text-xl text-green-50 max-w-2xl">
            Our commitment to sustainable e-waste management aligns with multiple UN Sustainable Development Goals,
            contributing to a cleaner, more sustainable future.
          </p>
        </div>
        <div className="absolute right-0 bottom-0 opacity-10">
          <Leaf size={240} />
        </div>
      </div>

      {/* SDG Goals */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">UN SDG Alignment</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-green-50 rounded-lg p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-green-600 text-white p-2 rounded-lg">
                <Globe2 size={24} />
              </div>
              <h3 className="font-semibold text-green-800">SDG 11</h3>
            </div>
            <h4 className="font-bold text-gray-800 mb-2">Sustainable Cities</h4>
            <p className="text-gray-600">Making cities inclusive, safe, resilient and sustainable through proper e-waste management.</p>
          </div>
          <div className="bg-green-50 rounded-lg p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-green-600 text-white p-2 rounded-lg">
                <Recycle size={24} />
              </div>
              <h3 className="font-semibold text-green-800">SDG 12</h3>
            </div>
            <h4 className="font-bold text-gray-800 mb-2">Responsible Consumption</h4>
            <p className="text-gray-600">Ensuring sustainable consumption and production patterns in electronics.</p>
          </div>
          <div className="bg-green-50 rounded-lg p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-green-600 text-white p-2 rounded-lg">
                <Leaf size={24} />
              </div>
              <h3 className="font-semibold text-green-800">SDG 13</h3>
            </div>
            <h4 className="font-bold text-gray-800 mb-2">Climate Action</h4>
            <p className="text-gray-600">Reducing carbon footprint through proper recycling and waste management.</p>
          </div>
        </div>
      </div>

      {/* Environmental Impact */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Environmental Impact</h2>
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Resource Conservation</h3>
            <ul className="space-y-3">
              {[
                'Reduces need for raw material extraction',
                'Conserves natural resources',
                'Minimizes mining impact',
                'Saves energy in production',
                'Reduces landfill usage'
              ].map(item => (
                <li key={item} className="flex items-center space-x-2 text-gray-600">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Pollution Prevention</h3>
            <ul className="space-y-3">
              {[
                'Prevents toxic leaching into soil',
                'Protects water resources',
                'Reduces air pollution',
                'Minimizes hazardous waste',
                'Controls greenhouse gas emissions'
              ].map(item => (
                <li key={item} className="flex items-center space-x-2 text-gray-600">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Circular Economy */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Circular Economy Approach</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="relative">
            <div className="bg-blue-50 rounded-lg p-6">
              <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Target className="text-blue-600" size={24} />
              </div>
              <h3 className="font-bold text-gray-800 mb-2">Design & Production</h3>
              <p className="text-gray-600">Sustainable design principles and eco-friendly manufacturing processes.</p>
            </div>
          </div>
          <div className="relative">
            <div className="bg-green-50 rounded-lg p-6">
              <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Recycle className="text-green-600" size={24} />
              </div>
              <h3 className="font-bold text-gray-800 mb-2">Collection & Recycling</h3>
              <p className="text-gray-600">Efficient collection systems and advanced recycling technologies.</p>
            </div>
          </div>
          <div className="relative">
            <div className="bg-yellow-50 rounded-lg p-6">
              <div className="bg-yellow-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="text-yellow-600" size={24} />
              </div>
              <h3 className="font-bold text-gray-800 mb-2">Resource Recovery</h3>
              <p className="text-gray-600">Material recovery and reintegration into production cycle.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Recycle className="w-12 h-12 text-green-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-2">E-Waste Collection</h1>
          <p className="text-gray-600">Help us make the world cleaner, one device at a time</p>
        </header>

        <nav className="bg-white shadow-lg mb-8 rounded-lg">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap justify-center items-center h-16 space-x-1 md:space-x-4">
              <button
                onClick={() => setCurrentView('info')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors duration-200 ${
                  currentView === 'info' ? 'bg-green-100 text-green-600' : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Recycle className="w-5 h-5" />
                <span>About</span>
              </button>
              <button
                onClick={() => setCurrentView('residential')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors duration-200 ${
                  currentView === 'residential' ? 'bg-green-100 text-green-600' : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Home className="w-5 h-5" />
                <span>Residential</span>
              </button>
              <button
                onClick={() => setCurrentView('commercial')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors duration-200 ${
                  currentView === 'commercial' ? 'bg-green-100 text-green-600' : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Building2 className="w-5 h-5" />
                <span>Commercial</span>
              </button>
              <button
                onClick={() => setCurrentView('sustainability')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors duration-200 ${
                  currentView === 'sustainability' ? 'bg-green-100 text-green-600' : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Leaf className="w-5 h-5" />
                <span>Sustainability</span>
              </button>
              <button
                onClick={() => {
                  setCurrentView('collection');
                  setStep(1);
                }}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors duration-200 ${
                  currentView === 'collection' ? 'bg-green-100 text-green-600' : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <MapPin className="w-5 h-5" />
                <span>Schedule</span>
              </button>
              <button
                onClick={() => setCurrentView('history')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors duration-200 ${
                  currentView === 'history' ? 'bg-green-100 text-green-600' : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <History className="w-5 h-5" />
                <span>History</span>
              </button>
            </div>
          </div>
        </nav>

        {currentView === 'info' && <EWasteInfo />}
        {currentView === 'residential' && renderResidentialContent()}
        {currentView === 'commercial' && renderCommercialContent()}
        {currentView === 'sustainability' && renderSustainabilityContent()}
        {currentView === 'history' && (
          <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8">
            <OrderHistory orders={orderHistory} />
          </div>
        )}

        {currentView === 'collection' && (
          <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
            <div className="flex justify-between mb-8">
              {[1, 2, 3].map((num) => (
                <div
                  key={num}
                  className={`flex items-center ${num <= step ? 'text-green-600' : 'text-gray-400'}`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      num <= step ? 'bg-green-600 text-white' : 'bg-gray-200'
                    }`}
                  >
                    {num === 1 ? <MapPin className="w-4 h-4" /> : num === 2 ? <Recycle className="w-4 h-4" /> : <CreditCard className="w-4 h-4" />}
                  </div>
                  <span className="ml-2 text-sm">
                    {num === 1 ? 'Address' : num === 2 ? 'Items' : 'Checkout'}
                  </span>
                </div>
              ))}
            </div>

            <form onSubmit={handleSubmit}>
              {step === 1 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Country</label>
                    <input
                      type="text"
                      required
                      value={address.country}
                      onChange={(e) => handleAddressChange('country', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">State</label>
                    <input
                      type="text"
                      required
                      value={address.state}
                      onChange={(e) => handleAddressChange('state', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">City</label>
                    <input
                      type="text"
                      required
                      value={address.city}
                      onChange={(e) => handleAddressChange('city', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Street Address</label>
                    <input
                      type="text"
                      required
                      value={address.street}
                      onChange={(e) => handleAddressChange('street', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">ZIP Code</label>
                    <input
                      type="text"
                      required
                      value={address.zipCode}
                      onChange={(e) => handleAddressChange('zipCode', e.target.value)}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    />
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <h3 className="text-lg font-medium text-gray-900">Select E-Waste Items</h3>
                  {items.map((item, index) => (
                    <div key={item.type} className="flex items-center justify-between">
                      <label className="text-sm font-medium text-gray-700">{item.type}</label>
                      <div className="flex items-center space-x-2">
                        <button
                          type="button"
                          onClick={() => handleQuantityChange(index, item.quantity - 1)}
                          className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
                        >
                          -
                        </button>
                        <span className="w-12 text-center">{item.quantity}</span>
                        <button
                          type="button"
                          onClick={() => handleQuantityChange(index, item.quantity + 1)}
                          className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <h3 className="text-lg font-medium text-gray-900">Checkout Summary</h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Pickup Address</h4>
                    <p className="text-sm text-gray-600">
                      {address.street}<br />
                      {address.city}, {address.state}<br />
                      {address.country} {address.zipCode}
                    </p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Items for Collection</h4>
                    {items.map((item) => (
                      item.quantity > 0 && (
                        <div key={item.type} className="flex justify-between text-sm text-gray-600">
                          <span>{item.type}</span>
                          <span>{item.quantity} units</span>
                        </div>
                      )
                    ))}
                    <div className="mt-4 pt-4 border-t">
                      <div className="flex justify-between font-medium">
                        <span>Total Items</span>
                        <span>{totalItems}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-8 flex justify-between">
                {step > 1 && (
                  <button
                    type="button"
                    onClick={() => setStep(step - 1)}
                    className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
                  >
                    <ChevronLeft className="w-4 h-4 mr-1"  />
                    Back
                  </button>
                )}
                <button
                  type="submit"
                  className="flex items-center px-6 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 ml-auto"
                >
                  {step === 3 ? 'Confirm Pickup' : 'Continue'}
                  <ChevronRight className="w-4 h-4 ml-1" />
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;