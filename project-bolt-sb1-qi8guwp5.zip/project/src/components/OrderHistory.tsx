import React from 'react';
import { Package, CheckCircle, Clock, Truck, Calendar, MapPin } from 'lucide-react';

interface Address {
  country: string;
  state: string;
  city: string;
  street: string;
  zipCode: string;
}

interface EWasteItem {
  type: string;
  quantity: number;
}

interface Order {
  id: string;
  date: string;
  address: Address;
  items: EWasteItem[];
  status: 'pending' | 'collected' | 'processed';
}

interface OrderHistoryProps {
  orders: Order[];
}

const OrderHistory: React.FC<OrderHistoryProps> = ({ orders }) => {
  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'collected':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'processed':
        return <Package className="w-5 h-5 text-blue-500" />;
    }
  };

  const getStatusText = (status: Order['status']) => {
    switch (status) {
      case 'collected':
        return 'Collected';
      case 'pending':
        return 'Pending Collection';
      case 'processed':
        return 'Processed';
    }
  };

  const getStatusTimeline = (status: Order['status']) => {
    const steps = [
      { icon: Clock, label: 'Scheduled', completed: true },
      { icon: Truck, label: 'Collection', completed: status === 'collected' || status === 'processed' },
      { icon: Package, label: 'Processing', completed: status === 'processed' }
    ];

    return (
      <div className="flex items-center space-x-4 mb-6">
        {steps.map((step, index) => (
          <React.Fragment key={step.label}>
            <div className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                step.completed ? 'bg-green-100' : 'bg-gray-100'
              }`}>
                <step.icon className={`w-4 h-4 ${step.completed ? 'text-green-600' : 'text-gray-400'}`} />
              </div>
              <span className={`text-xs mt-1 ${step.completed ? 'text-green-600' : 'text-gray-400'}`}>
                {step.label}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div className={`h-0.5 w-12 ${
                steps[index + 1].completed ? 'bg-green-500' : 'bg-gray-200'
              }`} />
            )}
          </React.Fragment>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold text-gray-800">Order History</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <span className="text-sm text-gray-600">Pending</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-sm text-gray-600">Collected</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
            <span className="text-sm text-gray-600">Processed</span>
          </div>
        </div>
      </div>

      {orders.map((order) => (
        <div key={order.id} className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="flex items-center space-x-3 mb-2">
                <h3 className="text-lg font-semibold text-gray-900">Order #{order.id}</h3>
                <div className={`px-3 py-1 rounded-full text-sm ${
                  order.status === 'collected' ? 'bg-green-100 text-green-700' :
                  order.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-blue-100 text-blue-700'
                }`}>
                  {getStatusText(order.status)}
                </div>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Calendar className="w-4 h-4" />
                <span>{new Date(order.date).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}</span>
              </div>
            </div>
          </div>

          {getStatusTimeline(order.status)}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-3">
                <MapPin className="w-4 h-4 text-gray-500" />
                <h4 className="text-sm font-medium text-gray-700">Pickup Location</h4>
              </div>
              <p className="text-sm text-gray-600">
                {order.address.street}<br />
                {order.address.city}, {order.address.state}<br />
                {order.address.country} {order.address.zipCode}
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Items for Collection</h4>
              <div className="space-y-2">
                {order.items.map((item, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="text-gray-600">{item.type}</span>
                    <span className="font-medium text-gray-700">{item.quantity} units</span>
                  </div>
                ))}
                <div className="pt-2 mt-2 border-t border-gray-200">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium text-gray-700">Total Items</span>
                    <span className="font-medium text-green-600">
                      {order.items.reduce((sum, item) => sum + item.quantity, 0)} units
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default OrderHistory;