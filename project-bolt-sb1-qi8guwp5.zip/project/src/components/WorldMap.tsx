import React from 'react';
import { Recycle, Target, Leaf, Factory, Battery, AlertTriangle, Globe2 } from 'lucide-react';

const EWasteInfo = () => {
  const sdgGoals = [
    {
      number: 11,
      title: "Sustainable Cities and Communities",
      description: "E-waste management contributes to making cities inclusive, safe, resilient and sustainable.",
      icon: Globe2
    },
    {
      number: 12,
      title: "Responsible Consumption and Production",
      description: "Proper e-waste handling ensures sustainable consumption and production patterns.",
      icon: Recycle
    },
    {
      number: 13,
      title: "Climate Action",
      description: "E-waste recycling helps reduce greenhouse gas emissions and combat climate change.",
      icon: Leaf
    }
  ];

  const recyclingSteps = [
    {
      title: "Collection",
      description: "Safe gathering of electronic waste from households and businesses",
      icon: Battery
    },
    {
      title: "Sorting",
      description: "Classification of e-waste by type and recyclability",
      icon: Target
    },
    {
      title: "Processing",
      description: "Dismantling and resource recovery through advanced techniques",
      icon: Factory
    }
  ];

  const hazardousComponents = [
    "Lead in CRT screens",
    "Mercury in flat-screen displays",
    "Cadmium in circuit boards",
    "Brominated flame retardants",
    "Lithium in batteries"
  ];

  const valuableComponents = [
    "Gold in circuit boards",
    "Silver in contacts",
    "Copper in wiring",
    "Platinum in hard drives",
    "Rare earth elements in electronics"
  ];

  return (
    <div className="space-y-12 py-8">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-green-600 to-emerald-800 text-white p-8 md:p-12">
        <div className="relative z-10">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">E-Waste Management</h1>
          <p className="text-lg md:text-xl text-green-50 max-w-2xl">
            Electronic waste is the fastest-growing waste stream globally, with over 50 million metric tons generated annually.
            Proper management is crucial for environmental sustainability and resource recovery.
          </p>
        </div>
        <div className="absolute right-0 bottom-0 opacity-10">
          <Recycle size={240} />
        </div>
      </div>

      {/* SDG Goals Section */}
      <section className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">UN Sustainable Development Goals</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {sdgGoals.map((goal) => (
            <div key={goal.number} className="bg-green-50 rounded-lg p-6">
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-green-600 text-white p-2 rounded-lg">
                  <goal.icon size={24} />
                </div>
                <h3 className="font-semibold text-green-800">SDG {goal.number}</h3>
              </div>
              <h4 className="font-bold text-gray-800 mb-2">{goal.title}</h4>
              <p className="text-gray-600">{goal.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Recycling Process */}
      <section className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">E-Waste Recycling Process</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {recyclingSteps.map((step, index) => (
            <div key={step.title} className="relative">
              {index < recyclingSteps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 right-0 w-full h-0.5 bg-green-200 transform translate-x-1/2" />
              )}
              <div className="relative bg-white border border-green-100 rounded-lg p-6">
                <div className="bg-green-100 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                  <step.icon className="text-green-600" size={24} />
                </div>
                <h3 className="font-bold text-gray-800 mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Components Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Hazardous Components */}
        <section className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center space-x-3 mb-6">
            <AlertTriangle className="text-red-500" size={24} />
            <h2 className="text-2xl font-bold text-gray-800">Hazardous Components</h2>
          </div>
          <ul className="space-y-3">
            {hazardousComponents.map((component) => (
              <li key={component} className="flex items-center space-x-3 text-gray-700">
                <div className="w-2 h-2 bg-red-500 rounded-full" />
                <span>{component}</span>
              </li>
            ))}
          </ul>
        </section>

        {/* Valuable Components */}
        <section className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center space-x-3 mb-6">
            <Battery className="text-yellow-500" size={24} />
            <h2 className="text-2xl font-bold text-gray-800">Valuable Materials</h2>
          </div>
          <ul className="space-y-3">
            {valuableComponents.map((component) => (
              <li key={component} className="flex items-center space-x-3 text-gray-700">
                <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                <span>{component}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>

      {/* Impact Statistics */}
      <section className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl shadow-lg p-8 text-white">
        <h2 className="text-2xl font-bold mb-6">Global Impact</h2>
        <div className="grid md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-green-400 mb-2">50M+</div>
            <div className="text-gray-300">Tons of E-waste Annually</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-green-400 mb-2">17%</div>
            <div className="text-gray-300">Global Recycling Rate</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-green-400 mb-2">$62.5B</div>
            <div className="text-gray-300">Value in Raw Materials</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-green-400 mb-2">2x</div>
            <div className="text-gray-300">Growth Rate vs Other Waste</div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EWasteInfo;